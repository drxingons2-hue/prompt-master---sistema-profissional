import { useState, useMemo } from 'react';
import {
  LayoutDashboard, HardHat, Users, UserCog, AlertTriangle, ShieldAlert,
  ClipboardCheck, GraduationCap, HardHat as Helmet, FileText, MessageSquare,
  FileCheck2, ClipboardList, CalendarDays, Sparkle as _unused, Building2,
  Search, Plus, ChevronRight, X, CheckCircle2, Clock, AlertCircle, Printer
} from 'lucide-react';

type Module =
  | 'menu' | 'obra' | 'funcionarios' | 'equipes' | 'dashboard' | 'acidentes'
  | 'nc' | 'inspecoes' | 'treinamentos' | 'epi' | 'documentacao' | 'dds'
  | 'pt' | 'pta' | 'planejamento' | 'formulario' | 'frentes' | 'docDashboard' | 'relatorios';

interface Funcionario {
  matricula: string; nome: string; empresa: string; cargo: string; encarregado: string;
  frente: string; situacao: 'Ativo' | 'Afastado' | 'Desligado'; admissao: string; asoVenc: string;
}

interface Alocacao {
  matricula: string; encarregado: string; inicio: string; fim: string; frente: string;
}

const FUNCIONARIOS: Funcionario[] = [
  { matricula: 'F001', nome: 'João Silva', empresa: 'Construtora Alfa', cargo: 'Pedreiro', encarregado: 'Carlos Oliveira', frente: 'Estrutura Bloco A', situacao: 'Ativo', admissao: '2024-03-10', asoVenc: '2025-09-15' },
  { matricula: 'F002', nome: 'Pedro Santos', empresa: 'Construtora Alfa', cargo: 'Servente', encarregado: 'Carlos Oliveira', frente: 'Estrutura Bloco A', situacao: 'Ativo', admissao: '2024-04-02', asoVenc: '2025-08-20' },
  { matricula: 'F003', nome: 'Marcos Lima', empresa: 'Construtora Alfa', cargo: 'Armador', encarregado: 'Carlos Oliveira', frente: 'Estrutura Bloco A', situacao: 'Ativo', admissao: '2024-05-15', asoVenc: '2025-11-01' },
  { matricula: 'F004', nome: 'Rafael Souza', empresa: 'Terceirizada Beta', cargo: 'Eletricista', encarregado: 'Ana Costa', frente: 'Instalações Elétricas', situacao: 'Ativo', admissao: '2024-06-01', asoVenc: '2025-07-10' },
  { matricula: 'F005', nome: 'Lucas Pereira', empresa: 'Terceirizada Beta', cargo: 'Auxiliar Elétrico', encarregado: 'Ana Costa', frente: 'Instalações Elétricas', situacao: 'Ativo', admissao: '2024-07-12', asoVenc: '2025-10-05' },
  { matricula: 'F006', nome: 'Bruno Almeida', empresa: 'Construtora Alfa', cargo: 'Operador de Grua', encarregado: 'Roberto Nunes', frente: 'Içamento', situacao: 'Ativo', admissao: '2024-02-20', asoVenc: '2025-06-30' },
  { matricula: 'F007', nome: 'Diego Rocha', empresa: 'Construtora Alfa', cargo: 'Carpinteiro', encarregado: 'Roberto Nunes', frente: 'Formas Bloco B', situacao: 'Afastado', admissao: '2024-01-15', asoVenc: '2025-05-12' },
];

const ALOCACOES: Alocacao[] = [
  { matricula: 'F001', encarregado: 'Carlos Oliveira', inicio: '2024-03-10', fim: '2099-12-31', frente: 'Estrutura Bloco A' },
  { matricula: 'F002', encarregado: 'Carlos Oliveira', inicio: '2024-04-02', fim: '2099-12-31', frente: 'Estrutura Bloco A' },
  { matricula: 'F003', encarregado: 'Carlos Oliveira', inicio: '2024-05-15', fim: '2099-12-31', frente: 'Estrutura Bloco A' },
  { matricula: 'F004', encarregado: 'Ana Costa', inicio: '2024-06-01', fim: '2099-12-31', frente: 'Instalações Elétricas' },
  { matricula: 'F005', encarregado: 'Ana Costa', inicio: '2024-07-12', fim: '2099-12-31', frente: 'Instalações Elétricas' },
  { matricula: 'F006', encarregado: 'Roberto Nunes', inicio: '2024-02-20', fim: '2099-12-31', frente: 'Içamento' },
  { matricula: 'F007', encarregado: 'Roberto Nunes', inicio: '2024-01-15', fim: '2099-12-31', frente: 'Formas Bloco B' },
];

const ENCARREGADOS = ['Carlos Oliveira', 'Ana Costa', 'Roberto Nunes'];

const ACIDENTES = [
  { id: 'AC-001', data: '2025-01-15', tipo: 'Incidente', empresa: 'Construtora Alfa', frente: 'Estrutura Bloco A', gravidade: 'Leve', status: 'Encerrado' },
  { id: 'AC-002', data: '2025-02-03', tipo: 'Quase Acidente', empresa: 'Terceirizada Beta', frente: 'Instalações Elétricas', gravidade: 'Sem lesão', status: 'Em análise' },
  { id: 'AC-003', data: '2025-02-20', tipo: 'Acidente', empresa: 'Construtora Alfa', frente: 'Içamento', gravidade: 'Moderada', status: 'Em investigação' },
];

const NCS = [
  { id: 'NC-001', data: '2025-01-20', origem: 'Inspeção', local: 'Bloco A - 3º pav', empresa: 'Construtora Alfa', risco: 'Alto', status: 'Aberta', prazo: '2025-02-10' },
  { id: 'NC-002', data: '2025-02-01', origem: 'Auditoria', local: 'Canteiro', empresa: 'Terceirizada Beta', risco: 'Médio', status: 'Em andamento', prazo: '2025-02-25' },
  { id: 'NC-003', data: '2025-01-05', origem: 'Inspeção', local: 'Andaime Bloco B', empresa: 'Construtora Alfa', risco: 'Crítico', status: 'Encerrada', prazo: '2025-01-20' },
];

const INSPECOES = [
  { id: 'IN-001', data: '2025-02-10', tipo: 'Trabalho em Altura', local: 'Bloco A', responsavel: 'Carlos Oliveira', status: 'Realizada' },
  { id: 'IN-002', data: '2025-02-12', tipo: 'Instalações Elétricas', local: 'Bloco B', responsavel: 'Ana Costa', status: 'Planejada' },
  { id: 'IN-003', data: '2025-02-14', tipo: 'EPIs e EPCs', local: 'Canteiro', responsavel: 'Roberto Nunes', status: 'Realizada' },
];

const TREINAMENTOS = [
  { id: 'TR-001', funcionario: 'João Silva', nr: 'NR-35', data: '2024-08-10', validade: '2026-08-10', status: 'Válido' },
  { id: 'TR-002', funcionario: 'Pedro Santos', nr: 'NR-18', data: '2024-06-15', validade: '2025-06-15', status: 'Próximo vencimento' },
  { id: 'TR-003', funcionario: 'Rafael Souza', nr: 'NR-10', data: '2023-05-01', validade: '2025-05-01', status: 'Vencido' },
];

const EPIS = [
  { id: 'EP-001', funcionario: 'João Silva', epi: 'Capacete', ca: '31469', data: '2024-09-01', condicao: 'Bom' },
  { id: 'EP-002', funcionario: 'Pedro Santos', epi: 'Luva de Raspa', ca: '11456', data: '2024-10-15', condicao: 'Bom' },
  { id: 'EP-003', funcionario: 'Rafael Souza', epi: 'Botina Eletricista', ca: '42315', data: '2024-11-20', condicao: 'Desgastado' },
];

const DOCUMENTOS = [
  { id: 'DOC-001', nome: 'PGR - Inventário de Riscos', empresa: 'Construtora Alfa', vencimento: '2025-12-31', status: 'Válido' },
  { id: 'DOC-002', nome: 'PCMSO', empresa: 'Construtora Alfa', vencimento: '2025-06-30', status: 'Próximo vencimento' },
  { id: 'DOC-003', nome: 'ASO - Rafael Souza', empresa: 'Terceirizada Beta', vencimento: '2025-07-10', status: 'Válido' },
];

const DDS_HIST = [
  { id: 'DDS-001', data: '2025-02-10', encarregado: 'Carlos Oliveira', tema: 'Trabalho em Altura', participantes: 3, status: 'Realizado' },
  { id: 'DDS-002', data: '2025-02-11', encarregado: 'Ana Costa', tema: 'Riscos Elétricos', participantes: 2, status: 'Realizado' },
  { id: 'DDS-003', data: '2025-02-12', encarregado: 'Roberto Nunes', tema: 'Içamento de Cargas', participantes: 2, status: 'Pendente' },
];

const PTS = [
  { id: 'PT-001', data: '2025-02-10', atividade: 'Trabalho em altura - Bloco A', encarregado: 'Carlos Oliveira', status: 'Liberada' },
  { id: 'PT-002', data: '2025-02-11', atividade: 'Instalação elétrica - Bloco B', encarregado: 'Ana Costa', status: 'Em elaboração' },
];

const PTAS = [
  { id: 'PTA-001', data: '2025-02-10', atividade: 'Concretagem Laje 3', encarregado: 'Carlos Oliveira', status: 'Aprovada' },
  { id: 'PTA-002', data: '2025-02-12', atividade: 'Içamento de vigas', encarregado: 'Roberto Nunes', status: 'Em revisão' },
];

const FRENTES = [
  { id: 'FR-01', nome: 'Estrutura Bloco A', local: 'Bloco A', empresa: 'Construtora Alfa', encarregado: 'Carlos Oliveira', atividade: 'Concretagem e armação', status: 'Em execução' },
  { id: 'FR-02', nome: 'Instalações Elétricas', local: 'Bloco B', empresa: 'Terceirizada Beta', encarregado: 'Ana Costa', atividade: 'Passagem de cabos', status: 'Em execução' },
  { id: 'FR-03', nome: 'Içamento', local: 'Canteiro', empresa: 'Construtora Alfa', encarregado: 'Roberto Nunes', atividade: 'Movimentação de cargas', status: 'Em execução' },
];

const MENU_ITEMS: { id: Module; label: string; icon: any; group: string }[] = [
  { id: 'menu', label: 'Menu Principal', icon: LayoutDashboard, group: 'Geral' },
  { id: 'obra', label: 'Cadastro da Obra', icon: Building2, group: 'Geral' },
  { id: 'dashboard', label: 'Dashboard Geral', icon: LayoutDashboard, group: 'Geral' },
  { id: 'funcionarios', label: 'Funcionários', icon: Users, group: 'Pessoal' },
  { id: 'equipes', label: 'Equipes e Encarregados', icon: UserCog, group: 'Pessoal' },
  { id: 'frentes', label: 'Frentes de Serviço', icon: HardHat, group: 'Pessoal' },
  { id: 'acidentes', label: 'Acidentes e Incidentes', icon: AlertTriangle, group: 'Ocorrências' },
  { id: 'nc', label: 'Não Conformidades', icon: ShieldAlert, group: 'Ocorrências' },
  { id: 'inspecoes', label: 'Inspeções', icon: ClipboardCheck, group: 'Ocorrências' },
  { id: 'treinamentos', label: 'Treinamentos', icon: GraduationCap, group: 'Controles' },
  { id: 'epi', label: 'EPI e EPC', icon: Helmet, group: 'Controles' },
  { id: 'documentacao', label: 'Documentação', icon: FileText, group: 'Controles' },
  { id: 'dds', label: 'DDS', icon: MessageSquare, group: 'Documentos' },
  { id: 'pt', label: 'PT', icon: FileCheck2, group: 'Documentos' },
  { id: 'pta', label: 'PTA', icon: ClipboardList, group: 'Documentos' },
  { id: 'planejamento', label: 'Planejamento Semanal', icon: CalendarDays, group: 'Documentos' },
  { id: 'formulario', label: 'Formulário Inteligente', icon: UserCog, group: 'Documentos' },
  { id: 'docDashboard', label: 'Dashboard Documentação', icon: LayoutDashboard, group: 'Documentos' },
  { id: 'relatorios', label: 'Relatórios', icon: Printer, group: 'Documentos' },
];

function Card({ title, value, hint, tone = 'default' }: { title: string; value: string | number; hint?: string; tone?: 'default' | 'ok' | 'warn' | 'danger' }) {
  const tones: Record<string, string> = {
    default: 'border-zinc-200',
    ok: 'border-emerald-300 bg-emerald-50',
    warn: 'border-amber-300 bg-amber-50',
    danger: 'border-red-300 bg-red-50',
  };
  return (
    <div className={`rounded-md border bg-white p-4 ${tones[tone]}`}>
      <p className="text-xs font-medium text-zinc-500 uppercase tracking-wide">{title}</p>
      <p className="text-2xl font-bold text-zinc-900 mt-1">{value}</p>
      {hint && <p className="text-xs text-zinc-500 mt-1">{hint}</p>}
    </div>
  );
}

function Table({ headers, rows }: { headers: string[]; rows: (string | number)[][] }) {
  return (
    <div className="overflow-x-auto rounded-md border border-zinc-200 bg-white">
      <table className="w-full text-sm">
        <thead className="bg-zinc-100 text-zinc-700">
          <tr>
            {headers.map((h) => (
              <th key={h} className="text-left px-3 py-2 font-semibold text-xs uppercase tracking-wide">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-t border-zinc-200 hover:bg-zinc-50">
              {r.map((c, j) => (
                <td key={j} className="px-3 py-2 text-zinc-800">{c}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    'Ativo': 'bg-emerald-100 text-emerald-800',
    'Válido': 'bg-emerald-100 text-emerald-800',
    'Realizada': 'bg-emerald-100 text-emerald-800',
    'Realizado': 'bg-emerald-100 text-emerald-800',
    'Encerrado': 'bg-emerald-100 text-emerald-800',
    'Encerrada': 'bg-emerald-100 text-emerald-800',
    'Liberada': 'bg-emerald-100 text-emerald-800',
    'Aprovada': 'bg-emerald-100 text-emerald-800',
    'Aberta': 'bg-red-100 text-red-800',
    'Vencido': 'bg-red-100 text-red-800',
    'Crítico': 'bg-red-100 text-red-800',
    'Alto': 'bg-orange-100 text-orange-800',
    'Próximo vencimento': 'bg-amber-100 text-amber-800',
    'Pendente': 'bg-amber-100 text-amber-800',
    'Em andamento': 'bg-amber-100 text-amber-800',
    'Em análise': 'bg-amber-100 text-amber-800',
    'Em investigação': 'bg-amber-100 text-amber-800',
    'Em elaboração': 'bg-amber-100 text-amber-800',
    'Em revisão': 'bg-amber-100 text-amber-800',
    'Planejada': 'bg-blue-100 text-blue-800',
    'Em execução': 'bg-blue-100 text-blue-800',
    'Afastado': 'bg-amber-100 text-amber-800',
    'Médio': 'bg-amber-100 text-amber-800',
    'Leve': 'bg-blue-100 text-blue-800',
    'Moderada': 'bg-orange-100 text-orange-800',
    'Sem lesão': 'bg-zinc-100 text-zinc-700',
  };
  return <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${map[status] || 'bg-zinc-100 text-zinc-700'}`}>{status}</span>;
}

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-4">
      <h2 className="text-xl font-bold text-zinc-900">{title}</h2>
      {subtitle && <p className="text-sm text-zinc-500 mt-1">{subtitle}</p>}
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState<Module>('menu');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const groups = useMemo(() => {
    const g: Record<string, typeof MENU_ITEMS> = {};
    MENU_ITEMS.forEach((m) => { (g[m.group] ||= []).push(m); });
    return g;
  }, []);

  return (
    <div className="min-h-screen bg-zinc-50 flex">
      <aside className={`${sidebarOpen ? 'w-64' : 'w-0'} transition-all bg-[#0f2a4a] text-white flex flex-col overflow-hidden shrink-0`}>
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <HardHat className="w-6 h-6 text-amber-400" />
            <div>
              <p className="font-bold text-sm leading-tight">SIGSO</p>
              <p className="text-[10px] text-white/60 leading-tight">Gestão de Segurança de Obras</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto py-2">
          {Object.entries(groups).map(([group, items]) => (
            <div key={group} className="mb-2">
              <p className="px-4 py-1 text-[10px] uppercase tracking-wider text-white/40 font-semibold">{group}</p>
              {items.map((item) => {
                const Icon = item.icon;
                const isActive = active === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActive(item.id)}
                    className={`w-full flex items-center gap-2 px-4 py-2 text-xs text-left transition-colors ${isActive ? 'bg-white/10 border-l-2 border-amber-400 text-white' : 'text-white/70 hover:bg-white/5 hover:text-white'}`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10 text-[10px] text-white/50">
          v1.0 · Obra: Residencial Vista Verde
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <header className="bg-white border-b border-zinc-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1.5 rounded-md hover:bg-zinc-100 text-zinc-600">
              <ChevronRight className={`w-4 h-4 transition-transform ${sidebarOpen ? 'rotate-180' : ''}`} />
            </button>
            <div>
              <p className="text-xs text-zinc-500">Obra</p>
              <p className="text-sm font-semibold text-zinc-900">Residencial Vista Verde</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-xs text-zinc-600">
            <span className="hidden sm:inline">Período: Fev/2025</span>
            <span className="px-2 py-1 rounded bg-emerald-100 text-emerald-800 font-medium">Sistema Ativo</span>
          </div>
        </header>

        <div className="p-6">
          {active === 'menu' && <MenuPrincipal onNavigate={setActive} />}
          {active === 'obra' && <Obra />}
          {active === 'funcionarios' && <Funcionarios />}
          {active === 'equipes' && <Equipes />}
          {active === 'frentes' && <Frentes />}
          {active === 'dashboard' && <Dashboard />}
          {active === 'acidentes' && <Acidentes />}
          {active === 'nc' && <NaoConformidades />}
          {active === 'inspecoes' && <Inspecoes />}
          {active === 'treinamentos' && <Treinamentos />}
          {active === 'epi' && <EPI />}
          {active === 'documentacao' && <Documentacao />}
          {active === 'dds' && <DDS />}
          {active === 'pt' && <PT />}
          {active === 'pta' && <PTA />}
          {active === 'planejamento' && <Planejamento />}
          {active === 'formulario' && <FormularioInteligente />}
          {active === 'docDashboard' && <DocDashboard />}
          {active === 'relatorios' && <Relatorios />}
        </div>
      </main>
    </div>
  );
}

function MenuPrincipal({ onNavigate }: { onNavigate: (m: Module) => void }) {
  const cards: { id: Module; label: string; desc: string; icon: any }[] = [
    { id: 'dashboard', label: 'Dashboard Geral', desc: 'Indicadores executivos da obra', icon: LayoutDashboard },
    { id: 'formulario', label: 'Formulário Inteligente', desc: 'Gerar DDS, PT e PTA por encarregado', icon: UserCog },
    { id: 'acidentes', label: 'Acidentes', desc: 'Registrar e investigar ocorrências', icon: AlertTriangle },
    { id: 'nc', label: 'Não Conformidades', desc: 'Plano de ação e tratativas', icon: ShieldAlert },
    { id: 'inspecoes', label: 'Inspeções', desc: 'Checklists de segurança', icon: ClipboardCheck },
    { id: 'documentacao', label: 'Documentação', desc: 'PGR, PCMSO, ASO e mais', icon: FileText },
  ];
  return (
    <div>
      <div className="rounded-md bg-[#0f2a4a] text-white p-6 mb-6">
        <p className="text-xs uppercase tracking-wider text-amber-400 font-semibold">SIGSO</p>
        <h1 className="text-2xl font-bold mt-1">Sistema Integrado de Gestão de Segurança de Obras</h1>
        <p className="text-sm text-white/70 mt-2 max-w-2xl">Gestão completa de segurança do trabalho, documentação operacional e conformidade legal em um único painel.</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-5">
          <div className="bg-white/10 rounded p-3"><p className="text-[10px] uppercase text-white/60">Efetivo Ativo</p><p className="text-xl font-bold">6</p></div>
          <div className="bg-white/10 rounded p-3"><p className="text-[10px] uppercase text-white/60">NCs Abertas</p><p className="text-xl font-bold">2</p></div>
          <div className="bg-white/10 rounded p-3"><p className="text-[10px] uppercase text-white/60">DDS no Mês</p><p className="text-xl font-bold">3</p></div>
          <div className="bg-white/10 rounded p-3"><p className="text-[10px] uppercase text-white/60">Docs Vencendo</p><p className="text-xl font-bold">1</p></div>
        </div>
      </div>
      <SectionTitle title="Módulos do Sistema" subtitle="Acesse rapidamente os principais recursos" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <button key={c.id} onClick={() => onNavigate(c.id)} className="text-left rounded-md border border-zinc-200 bg-white p-4 hover:border-[#0f2a4a] hover:shadow-sm transition-all">
              <div className="flex items-center gap-2 mb-2">
                <div className="p-1.5 rounded bg-[#0f2a4a]/10"><Icon className="w-4 h-4 text-[#0f2a4a]" /></div>
                <p className="font-semibold text-sm text-zinc-900">{c.label}</p>
              </div>
              <p className="text-xs text-zinc-500">{c.desc}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Obra() {
  const fields = [
    ['Nome da Obra', 'Residencial Vista Verde'],
    ['Empresa Contratante', 'Vista Verde Empreendimentos'],
    ['Empresa Executora', 'Construtora Alfa Ltda'],
    ['CNPJ', '12.345.678/0001-90'],
    ['Endereço', 'Av. das Palmeiras, 1200 - São Paulo/SP'],
    ['Responsável pela Obra', 'Eng. Mariana Ribeiro'],
    ['Engenheiro Responsável', 'Eng. Paulo Mendes (CREA 12345)'],
    ['Responsável Seg. Trabalho', 'Téc. Seg. Fernanda Alves'],
    ['Data de Início', '2024-01-15'],
    ['Previsão de Término', '2026-06-30'],
    ['Efetivo Previsto', '45'],
    ['Efetivo Atual', '6'],
    ['Turnos', '07:00 - 16:00 / 16:00 - 01:00'],
    ['Atividades Principais', 'Estrutura, alvenaria, instalações'],
    ['Empresas Terceirizadas', 'Terceirizada Beta (Elétrica)'],
    ['Responsável Emergência', 'Carlos Oliveira (Ramal 101)'],
  ];
  return (
    <div>
      <SectionTitle title="Cadastro da Obra" subtitle="Informações gerais do empreendimento" />
      <div className="rounded-md border border-zinc-200 bg-white divide-y divide-zinc-200">
        {fields.map(([k, v]) => (
          <div key={k} className="grid grid-cols-1 sm:grid-cols-3 gap-2 px-4 py-2.5 text-sm">
            <span className="text-zinc-500 font-medium">{k}</span>
            <span className="sm:col-span-2 text-zinc-900">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Funcionarios() {
  const [busca, setBusca] = useState('');
  const filtrados = FUNCIONARIOS.filter((f) =>
    f.nome.toLowerCase().includes(busca.toLowerCase()) || f.matricula.toLowerCase().includes(busca.toLowerCase())
  );
  return (
    <div>
      <SectionTitle title="Cadastro de Funcionários" subtitle="Base centralizada de colaboradores" />
      <div className="flex items-center gap-2 mb-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-2.5 top-2.5 text-zinc-400" />
          <input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar por nome ou matrícula" className="w-full pl-8 pr-3 py-2 text-sm rounded-md border border-zinc-300 bg-white focus:outline-none focus:border-[#0f2a4a]" />
        </div>
        <button className="flex items-center gap-1 px-3 py-2 rounded-md bg-[#0f2a4a] text-white text-sm font-medium hover:bg-[#0f2a4a]/90"><Plus className="w-4 h-4" /> Novo</button>
      </div>
      <Table
        headers={['Matrícula', 'Nome', 'Empresa', 'Cargo', 'Encarregado', 'Frente', 'Situação', 'ASO Venc.']}
        rows={filtrados.map((f) => [f.matricula, f.nome, f.empresa, f.cargo, f.encarregado, f.frente, <StatusBadge key={f.matricula} status={f.situacao} />, f.asoVenc])}
      />
    </div>
  );
}

function Equipes() {
  return (
    <div>
      <SectionTitle title="Equipes e Encarregados" subtitle="Histórico de alocações por encarregado" />
      <Table
        headers={['Matrícula', 'Funcionário', 'Encarregado', 'Frente', 'Início', 'Fim']}
        rows={ALOCACOES.map((a) => {
          const f = FUNCIONARIOS.find((x) => x.matricula === a.matricula);
          return [a.matricula, f?.nome || '-', a.encarregado, a.frente, a.inicio, a.fim === '2099-12-31' ? 'Atual' : a.fim];
        })}
      />
    </div>
  );
}

function Frentes() {
  return (
    <div>
      <SectionTitle title="Frentes de Serviço" subtitle="Atividades e responsáveis por frente" />
      <Table
        headers={['Código', 'Frente', 'Local', 'Empresa', 'Encarregado', 'Atividade', 'Status']}
        rows={FRENTES.map((f) => [f.id, f.nome, f.local, f.empresa, f.encarregado, f.atividade, <StatusBadge key={f.id} status={f.status} />])}
      />
    </div>
  );
}

function Dashboard() {
  return (
    <div>
      <SectionTitle title="Dashboard Geral da Obra" subtitle="Indicadores executivos consolidados" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <Card title="Efetivo Ativo" value={6} hint="de 45 previstos" tone="ok" />
        <Card title="Acidentes no Mês" value={1} hint="1 em investigação" tone="warn" />
        <Card title="NCs Abertas" value={2} hint="1 vencida" tone="danger" />
        <Card title="Treinamentos Válidos" value="67%" hint="2 de 3" tone="warn" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="rounded-md border border-zinc-200 bg-white p-4">
          <p className="text-sm font-semibold text-zinc-900 mb-3">Efetivo por Empresa</p>
          {[['Construtora Alfa', 4], ['Terceirizada Beta', 2]].map(([n, v]) => (
            <div key={n as string} className="mb-2">
              <div className="flex justify-between text-xs mb-1"><span className="text-zinc-700">{n}</span><span className="font-semibold">{v}</span></div>
              <div className="h-2 bg-zinc-100 rounded"><div className="h-2 bg-[#0f2a4a] rounded" style={{ width: `${((v as number) / 6) * 100}%` }} /></div>
            </div>
          ))}
        </div>
        <div className="rounded-md border border-zinc-200 bg-white p-4">
          <p className="text-sm font-semibold text-zinc-900 mb-3">Ocorrências por Tipo</p>
          {[['Incidente', 1], ['Quase Acidente', 1], ['Acidente', 1]].map(([n, v]) => (
            <div key={n as string} className="flex justify-between text-sm py-1.5 border-b border-zinc-100 last:border-0">
              <span className="text-zinc-700">{n}</span><span className="font-semibold text-zinc-900">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Acidentes() {
  return (
    <div>
      <SectionTitle title="Acidentes e Incidentes" subtitle="Registro e investigação de ocorrências" />
      <Table
        headers={['Nº', 'Data', 'Tipo', 'Empresa', 'Frente', 'Gravidade', 'Status']}
        rows={ACIDENTES.map((a) => [a.id, a.data, a.tipo, a.empresa, a.frente, <StatusBadge key={a.id} status={a.gravidade} />, <StatusBadge key={a.id + 's'} status={a.status} />])}
      />
    </div>
  );
}

function NaoConformidades() {
  return (
    <div>
      <SectionTitle title="Não Conformidades e Plano de Ação" subtitle="Tratativas e prazos" />
      <Table
        headers={['Código', 'Data', 'Origem', 'Local', 'Empresa', 'Risco', 'Prazo', 'Status']}
        rows={NCS.map((n) => [n.id, n.data, n.origem, n.local, n.empresa, <StatusBadge key={n.id} status={n.risco} />, n.prazo, <StatusBadge key={n.id + 's'} status={n.status} />])}
      />
    </div>
  );
}

function Inspecoes() {
  return (
    <div>
      <SectionTitle title="Inspeções de Segurança" subtitle="Checklists planejados e realizados" />
      <Table
        headers={['Código', 'Data', 'Tipo', 'Local', 'Responsável', 'Status']}
        rows={INSPECOES.map((i) => [i.id, i.data, i.tipo, i.local, i.responsavel, <StatusBadge key={i.id} status={i.status} />])}
      />
    </div>
  );
}

function Treinamentos() {
  return (
    <div>
      <SectionTitle title="Treinamentos e Qualificações" subtitle="Controle de validade por NR" />
      <Table
        headers={['Código', 'Funcionário', 'NR', 'Realização', 'Validade', 'Status']}
        rows={TREINAMENTOS.map((t) => [t.id, t.funcionario, t.nr, t.data, t.validade, <StatusBadge key={t.id} status={t.status} />])}
      />
    </div>
  );
}

function EPI() {
  return (
    <div>
      <SectionTitle title="Controle de EPI e EPC" subtitle="Entregas e condições" />
      <Table
        headers={['Código', 'Funcionário', 'EPI', 'CA', 'Entrega', 'Condição']}
        rows={EPIS.map((e) => [e.id, e.funcionario, e.epi, e.ca, e.data, e.condicao])}
      />
    </div>
  );
}

function Documentacao() {
  return (
    <div>
      <SectionTitle title="Controle de Documentação" subtitle="PGR, PCMSO, ASO e demais documentos legais" />
      <Table
        headers={['Código', 'Documento', 'Empresa', 'Vencimento', 'Status']}
        rows={DOCUMENTOS.map((d) => [d.id, d.nome, d.empresa, d.vencimento, <StatusBadge key={d.id} status={d.status} />])}
      />
    </div>
  );
}

function DDS() {
  return (
    <div>
      <SectionTitle title="DDS — Diálogo Diário de Segurança" subtitle="Histórico de DDS realizados" />
      <Table
        headers={['Código', 'Data', 'Encarregado', 'Tema', 'Participantes', 'Status']}
        rows={DDS_HIST.map((d) => [d.id, d.data, d.encarregado, d.tema, d.participantes, <StatusBadge key={d.id} status={d.status} />])}
      />
    </div>
  );
}

function PT() {
  return (
    <div>
      <SectionTitle title="Permissão de Trabalho (PT)" subtitle="Autorizações formais de atividades críticas" />
      <Table
        headers={['Código', 'Data', 'Atividade', 'Encarregado', 'Status']}
        rows={PTS.map((p) => [p.id, p.data, p.atividade, p.encarregado, <StatusBadge key={p.id} status={p.status} />])}
      />
    </div>
  );
}

function PTA() {
  return (
    <div>
      <SectionTitle title="PTA — Planejamento da Tarefa" subtitle="Análise de riscos por etapa" />
      <Table
        headers={['Código', 'Data', 'Atividade', 'Encarregado', 'Status']}
        rows={PTAS.map((p) => [p.id, p.data, p.atividade, p.encarregado, <StatusBadge key={p.id} status={p.status} />])}
      />
    </div>
  );
}

function Planejamento() {
  const semanas = [
    { semana: 'Semana 07/2025', periodo: '10/02 a 16/02', encarregado: 'Carlos Oliveira', dds: 5, pt: 2, pta: 1, status: 'Em elaboração' },
    { semana: 'Semana 07/2025', periodo: '10/02 a 16/02', encarregado: 'Ana Costa', dds: 5, pt: 3, pta: 1, status: 'Aprovada' },
    { semana: 'Semana 07/2025', periodo: '10/02 a 16/02', encarregado: 'Roberto Nunes', dds: 5, pt: 1, pta: 2, status: 'Pendente' },
  ];
  return (
    <div>
      <SectionTitle title="Planejamento e Emissão Semanal" subtitle="Calendário de documentação por equipe" />
      <Table
        headers={['Semana', 'Período', 'Encarregado', 'DDS', 'PT', 'PTA', 'Status']}
        rows={semanas.map((s) => [s.semana, s.periodo, s.encarregado, s.dds, s.pt, s.pta, <StatusBadge key={s.encarregado} status={s.status} />])}
      />
    </div>
  );
}

function FormularioInteligente() {
  const [data, setData] = useState('2025-02-12');
  const [tipo, setTipo] = useState<'DDS' | 'PT' | 'PTA'>('DDS');
  const [encarregado, setEncarregado] = useState('Carlos Oliveira');
  const [tema, setTema] = useState('Trabalho em altura e uso de cinto');
  const [atividade, setAtividade] = useState('Concretagem de laje - Bloco A');
  const [local, setLocal] = useState('Bloco A - 3º pavimento');
  const [presenca, setPresenca] = useState<Record<string, boolean>>({});

  const equipe = useMemo(() => {
    const alocs = ALOCACOES.filter((a) => a.encarregado === encarregado && a.inicio <= data && a.fim >= data);
    return alocs.map((a) => FUNCIONARIOS.find((f) => f.matricula === a.matricula)).filter(Boolean) as Funcionario[];
  }, [encarregado, data]);

  const togglePresenca = (mat: string) => setPresenca((p) => ({ ...p, [mat]: !p[mat] }));

  return (
    <div>
      <SectionTitle title="Formulário Inteligente por Encarregado" subtitle="Carrega automaticamente a equipe ativa na data selecionada" />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-1 rounded-md border border-zinc-200 bg-white p-4 space-y-3">
          <div>
            <label className="text-xs font-medium text-zinc-600 block mb-1">Data do Documento</label>
            <input type="date" value={data} onChange={(e) => setData(e.target.value)} className="w-full px-3 py-2 text-sm rounded-md border border-zinc-300 focus:outline-none focus:border-[#0f2a4a]" />
          </div>
          <div>
            <label className="text-xs font-medium text-zinc-600 block mb-1">Tipo de Documento</label>
            <select value={tipo} onChange={(e) => setTipo(e.target.value as any)} className="w-full px-3 py-2 text-sm rounded-md border border-zinc-300 bg-white focus:outline-none focus:border-[#0f2a4a]">
              <option>DDS</option><option>PT</option><option>PTA</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-zinc-600 block mb-1">Encarregado</label>
            <select value={encarregado} onChange={(e) => setEncarregado(e.target.value)} className="w-full px-3 py-2 text-sm rounded-md border border-zinc-300 bg-white focus:outline-none focus:border-[#0f2a4a]">
              {ENCARREGADOS.map((e) => <option key={e}>{e}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-zinc-600 block mb-1">Atividade</label>
            <input value={atividade} onChange={(e) => setAtividade(e.target.value)} className="w-full px-3 py-2 text-sm rounded-md border border-zinc-300 focus:outline-none focus:border-[#0f2a4a]" />
          </div>
          <div>
            <label className="text-xs font-medium text-zinc-600 block mb-1">Tema / Descrição</label>
            <input value={tema} onChange={(e) => setTema(e.target.value)} className="w-full px-3 py-2 text-sm rounded-md border border-zinc-300 focus:outline-none focus:border-[#0f2a4a]" />
          </div>
          <div>
            <label className="text-xs font-medium text-zinc-600 block mb-1">Local</label>
            <input value={local} onChange={(e) => setLocal(e.target.value)} className="w-full px-3 py-2 text-sm rounded-md border border-zinc-300 focus:outline-none focus:border-[#0f2a4a]" />
          </div>
        </div>

        <div className="lg:col-span-2 rounded-md border border-zinc-200 bg-white p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-semibold text-zinc-900">Equipe de {encarregado}</p>
              <p className="text-xs text-zinc-500">Data de referência: {data} · {equipe.length} integrante(s)</p>
            </div>
            <span className="px-2 py-1 rounded bg-[#0f2a4a]/10 text-[#0f2a4a] text-xs font-medium">{tipo}</span>
          </div>

          {equipe.length === 0 ? (
            <div className="rounded-md border border-amber-300 bg-amber-50 p-4 text-sm text-amber-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold">Nenhuma equipe vinculada</p>
                <p className="text-xs mt-1">Não há funcionários alocados para este encarregado na data selecionada. Verifique o cadastro de equipes.</p>
              </div>
            </div>
          ) : (
            <div className="rounded-md border border-zinc-200 overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-zinc-100 text-zinc-700">
                  <tr>
                    <th className="text-left px-3 py-2 text-xs font-semibold">Presença</th>
                    <th className="text-left px-3 py-2 text-xs font-semibold">Matrícula</th>
                    <th className="text-left px-3 py-2 text-xs font-semibold">Nome</th>
                    <th className="text-left px-3 py-2 text-xs font-semibold">Função</th>
                    <th className="text-left px-3 py-2 text-xs font-semibold">Empresa</th>
                  </tr>
                </thead>
                <tbody>
                  {equipe.map((f) => (
                    <tr key={f.matricula} className="border-t border-zinc-200 hover:bg-zinc-50">
                      <td className="px-3 py-2">
                        <input type="checkbox" checked={!!presenca[f.matricula]} onChange={() => togglePresenca(f.matricula)} className="w-4 h-4 accent-[#0f2a4a]" />
                      </td>
                      <td className="px-3 py-2 text-zinc-700">{f.matricula}</td>
                      <td className="px-3 py-2 font-medium text-zinc-900">{f.nome}</td>
                      <td className="px-3 py-2 text-zinc-700">{f.cargo}</td>
                      <td className="px-3 py-2 text-zinc-700">{f.empresa}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="mt-4 flex flex-wrap gap-2">
            <button className="flex items-center gap-1 px-3 py-2 rounded-md bg-[#0f2a4a] text-white text-sm font-medium hover:bg-[#0f2a4a]/90">
              <CheckCircle2 className="w-4 h-4" /> Gerar {tipo}
            </button>
            <button className="flex items-center gap-1 px-3 py-2 rounded-md border border-zinc-300 bg-white text-sm font-medium text-zinc-700 hover:bg-zinc-50">
              <Printer className="w-4 h-4" /> Pré-visualizar
            </button>
            <button className="flex items-center gap-1 px-3 py-2 rounded-md border border-zinc-300 bg-white text-sm font-medium text-zinc-700 hover:bg-zinc-50">
              <X className="w-4 h-4" /> Limpar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function DocDashboard() {
  return (
    <div>
      <SectionTitle title="Dashboard de Documentação" subtitle="Indicadores de emissão e conformidade" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <Card title="DDS no Mês" value={3} hint="2 realizados · 1 pendente" tone="warn" />
        <Card title="PT Liberadas" value={1} hint="1 em elaboração" tone="warn" />
        <Card title="PTA Aprovadas" value={1} hint="1 em revisão" tone="warn" />
        <Card title="Docs Vencendo" value={1} hint="PCMSO em 30 dias" tone="danger" />
      </div>
      <div className="rounded-md border border-zinc-200 bg-white p-4">
        <p className="text-sm font-semibold text-zinc-900 mb-3">Documentos por Encarregado</p>
        {[['Carlos Oliveira', 8], ['Ana Costa', 6], ['Roberto Nunes', 4]].map(([n, v]) => (
          <div key={n as string} className="mb-2">
            <div className="flex justify-between text-xs mb-1"><span className="text-zinc-700">{n}</span><span className="font-semibold">{v}</span></div>
            <div className="h-2 bg-zinc-100 rounded"><div className="h-2 bg-[#0f2a4a] rounded" style={{ width: `${((v as number) / 8) * 100}%` }} /></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Relatorios() {
  const rels = [
    'Relatório Mensal de Segurança',
    'Relatório de Acidentes e Incidentes',
    'Relatório de Não Conformidades',
    'Relatório de Inspeções',
    'Relatório de Treinamentos',
    'Relação de Funcionários por Encarregado',
    'Lista de Documentação Pendente',
    'Relatório de DDS',
    'PT e PTA por Período',
    'Resumo Semanal de Segurança',
  ];
  return (
    <div>
      <SectionTitle title="Relatórios e Impressão" subtitle="Documentos prontos para exportação em PDF" />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {rels.map((r) => (
          <div key={r} className="flex items-center justify-between rounded-md border border-zinc-200 bg-white px-4 py-3">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#0f2a4a]" />
              <span className="text-sm text-zinc-800">{r}</span>
            </div>
            <button className="flex items-center gap-1 px-2.5 py-1 rounded border border-zinc-300 text-xs font-medium text-zinc-700 hover:bg-zinc-50">
              <Printer className="w-3.5 h-3.5" /> PDF
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}